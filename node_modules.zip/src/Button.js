

import react from 'react'
export default function Button(){
  return (
    <>
    <button id ="comp">Submit</button>
    </>
  )
}