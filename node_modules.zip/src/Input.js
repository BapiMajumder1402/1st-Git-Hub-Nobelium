import react from 'react'

export default function Input(){
  return (
    <>
        <input id="comp" type="text" placeholder="Mobile ..."/>  
        <br/>
        <input id="comp" type="text" placeholder ="Password ..."/>
    </>
  )
}