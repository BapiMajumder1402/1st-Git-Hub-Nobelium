import  react from 'react'

export default function H1(){
  return(
    <h1>Register Here ...</h1>
  )
}