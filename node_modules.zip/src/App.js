// import logo from './logo.svg';
import './App.css';
import H1 from './H1';
import Input from './Input';
import Button from './Button';

function App() {
  return (
    // <>
    //    <h1>Register Here ...</h1>
    //      <input id="comp" type="text" placeholder="Mobile ..."/>  
    //      <br/>
    //      <input id="comp" type="text" placeholder ="Password ..."/>
    //      <br/>
    //      <button id="comp">Submit</button>
    // </>
    
        ///////////////////////////////////////////////////////////////////////////////////
    
    <>
      
    <H1></H1>
    <Input></Input>
    <br />
    <Button></Button>
      
      </>
    
  );
}

export default App;
